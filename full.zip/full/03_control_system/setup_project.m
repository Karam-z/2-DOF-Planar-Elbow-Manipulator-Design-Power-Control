clear; clc; close all;


steptime = 1e-4;   
stoptime = 6;      

% Electrical Constants
L = 2.2e-3;        % Armature Inductance = 2.2 mH 
R = 0.96;          % Armature Resistance = 0.96 Ohm 
Vs = 12;           % Supply Voltage = 12V 
Ke = 0.5;          % Back EMF Constant 
Kt = 0.5;          % Torque Constant 

% Mechanical Constants 

m1 = 1; m2 = 1;    % Mass of Link 1 and 2
l1 = 1; l2 = 1;    % Length of Link 1 and 2
g = 9.81;          % Gravity
r = 4;             % Gear reduction ratio
J = 118.2e-3;      % Motor Inertia 
B = 129.6e-3;      % Motor Friction 

% Controller Gains 

% Electrical PI Gains
Kp_elec = 5;       
Ki_elec = 100;

% Mechanical PID Gains (Outer Loop)
Kp_mech = 150;     
Ki_mech = 10;
Kd_mech = 60;