    function [result] = dynamics(input)
    
    T1 = input(1);
    T2 = input(2);
    q1 = input(3);
    q2 = input(4);
    q1dot = input(5);
    q2dot = input(6);
    
    m1 = 1;       %mass of link 1 + mass of motor 2
    m2 = 1;       %mass of link 2
    l1 = 1;       %length of link 1 (joint-to-joint)
    lc1 = 1;      %center of mass location for link 1 (from initial joint)
    l2 = 1;       %length of link 2 (joint-to-joint)
    lc2 = 1;      %center of mass location for link 2 (from initial joint)
    I1 = 1;       %moment of inertia around center of mass for link 1 (parallel to axis of rotation)
    I2 = 1;       %moment of inertia around center of mass for link 2 (parallel to axis of rotation)
    g = 9.81;     %gravity constant
    
    r = 4;          %gear reduction
    J = 118.2e-3;   %motor inertia
    B = 129.6e-3;   %motor friction constant
    
    h = m2*l1*lc2*sin(q2);
    d11 = m1*(lc1^2)+m2*((l1^2)+(lc2^2)+2*l1*lc2*cos(q2))+I1+I2;
    d12 = m2*((lc2^2)+l1*lc2*cos(q2))+I2;
    d21 = d12;
    d22 = m2*(lc2^2)+I2;
    g1 = (m1*lc1+m2*l1)*g*cos(q1)+m2*lc2*g*cos(q1+q2);
    g2 = m2*lc2*g*cos(q1+q2);
    
    q1dotdot = (T1+2*h*q1dot*q2dot+h*(q2dot^2)-g1-r*B*q1dot-(d12/d22)*(T2-h*(q1dot^2)-g2))/(d11-(d12*d21/d22)+(r^2)*J);
        
    q2dotdot = (T2-d21*q1dotdot-h*(q1dot^2)-g2-r*B*q2dot)/(d22+(r^2)*J);
    
    result = [q1dotdot q2dotdot];
    end