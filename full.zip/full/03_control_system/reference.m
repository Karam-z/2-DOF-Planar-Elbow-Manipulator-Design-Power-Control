function result = reference(t)
   
    
    
    P0 = [1.95, 0.0]; 
    P1 = [0.7, 0.0];
    P2 = [0.4, 0.0]; 
    P3 = [0.3, 0.4];
    P4 = [0.5, 0.4];
    
    % TIMING LOGIC
    if t < 2.0
       
        ratio = t / 2.0;
        current_pos = P0 + (P1 - P0) * ratio;
        
    elseif t < 3.5
        % Phase 2: Move 0.7 -> 0.4
        ratio = (t - 2.0) / 1.5;
        current_pos = P1 + (P2 - P1) * ratio;
        
    elseif t < 5.0
        % Phase 3: Move 0.4 -> 0.3
        ratio = (t - 3.5) / 1.5;
        current_pos = P2 + (P3 - P2) * ratio;
        
    elseif t < 6.5
        % Phase 4: Move 0.3 -> 0.5
        ratio = (t - 5.0) / 1.5;
        current_pos = P3 + (P4 - P3) * ratio;
        
    else
       
        current_pos = P4;
    end
    
    result = current_pos'; 
end