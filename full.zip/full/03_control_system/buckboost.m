function Va = buckboost(D)
    Vs = 12; % Supply voltage [cite: 166]

    % Safety saturation: D cannot physically be 1 (division by zero).
    % We limit it to 0.95 maximum.
    if D > 0.95
        D = 0.95;
    elseif D < -0.95
        D = -0.95;
    end

    Va = (D / (1 - D)) * Vs;
end