function pos = forward_kinematics(q)
    
    l1 = 1.0; 
    l2 = 1.0; 
    
    q1 = q(1);
    q2 = q(2);
    
    % Calculate X and Y
    x = l1 * cos(q1) + l2 * cos(q1 + q2);
    y = l1 * sin(q1) + l2 * sin(q1 + q2);
    
    pos = [x; y];
end