function q_ref = invkine(pos)
    x = pos(1); y = pos(2);
    l1 = 1; l2 = 1; % Lengths from dynamics.m

    % Calculate theta2 (Elbow)
    c2 = (x^2 + y^2 - l1^2 - l2^2) / (2*l1*l2);
    s2 = sqrt(1 - c2^2); 
    theta2 = atan2(s2, c2);

    % Calculate theta1 (Shoulder)
    k1 = l1 + l2*cos(theta2);
    k2 = l2*sin(theta2);
    theta1 = atan2(y, x) - atan2(k2, k1);

    q_ref = [theta1; theta2];
end